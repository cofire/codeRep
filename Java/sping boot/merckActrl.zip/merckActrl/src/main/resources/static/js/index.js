/**
 * 测试js
 */

window.onload=function(){
	alert(1);
}