package com.merck.controller;

public class BaseController {

}
